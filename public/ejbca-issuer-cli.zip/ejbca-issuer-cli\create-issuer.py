#!/usr/bin/env python3
"""
EJBCA Issuer CLI — Self-service issuer management for Thiqa PKI.

Usage:
    python3 create-issuer.py create <org_name> <password> [--country SD]
    python3 create-issuer.py list
    python3 create-issuer.py disable <username>
    python3 create-issuer.py enable <username>
    python3 create-issuer.py renew <username>
    python3 create-issuer.py (interactive mode)
"""

import argparse
import json
import os
import re
import subprocess
import sys
import unicodedata
from datetime import datetime, timezone

CONFIG_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ejbca-config.json")


def load_config():
    if not os.path.exists(CONFIG_FILE):
        print(f"Error: Config file not found: {CONFIG_FILE}")
        print("Create it with the required connection settings.")
        sys.exit(1)
    with open(CONFIG_FILE, "r") as f:
        return json.load(f)


def sanitize_username(name):
    name = unicodedata.normalize("NFKD", name).encode("ascii", "ignore").decode("ascii")
    name = name.lower().strip()
    name = re.sub(r"[^a-z0-9]+", "-", name)
    name = name.strip("-")
    return f"issuer-{name}"


def ssh_connect(config):
    import paramiko
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(
        config["host"],
        port=config.get("port", 22),
        username=config["ssh_username"],
        password=config["ssh_password"],
        timeout=10,
    )
    return client


def run_cli(client, config, command):
    cli_pw = config["ejbca_cli_password"]
    full_cmd = f"docker exec ejbca /opt/keyfactor/bin/ejbca.sh {command} --clipassword {cli_pw} 2>&1"
    stdin, stdout, stderr = client.exec_command(full_cmd, timeout=30)
    return stdout.read().decode().strip()


def run_command(client, cmd, timeout=30):
    stdin, stdout, stderr = client.exec_command(cmd, timeout=timeout)
    return stdout.read().decode().strip(), stderr.read().decode().strip()


def entity_exists(client, config, username):
    cmd = (
        f"docker exec ejbca-database mariadb -u ejbca -pejbca ejbca -e "
        f"\"SELECT COUNT(*) FROM UserData WHERE username='{username}';\" 2>&1"
    )
    result, _ = run_command(client, cmd)
    return "1" in result and "COUNT(*)" not in result.split("\n")[-1].strip()[:3]


def create_issuer(org_name, password, country=None):
    config = load_config()
    if country is None:
        country = config.get("default_country", "SD")

    if len(password) < 8:
        print("Error: Password must be at least 8 characters.")
        sys.exit(1)

    username = sanitize_username(org_name)
    dn = f"CN={org_name},O={org_name},C={country}"

    print(f"Creating end entity: {username}")
    print(f"  DN: {dn}")
    print(f"  CA: {config['ca_name']}")
    print(f"  Cert Profile: {config['cert_profile']}")
    print(f"  EE Profile: {config['ee_profile']}")
    print()

    client = ssh_connect(config)
    try:
        if entity_exists(client, config, username):
            print(f"Error: End entity '{username}' already exists.")
            print("Use 'list' to see all issuers, or choose a different name.")
            sys.exit(1)

        cmd = (
            f'ra addendentity '
            f'--username {username} '
            f'--dn "{dn}" '
            f'--caname {config["ca_name"]} '
            f'--type 1 '
            f'--certprofile {config["cert_profile"]} '
            f'--eeprofile {config["ee_profile"]} '
            f'--token P12 '
            f'--password {password}'
        )
        result = run_cli(client, config, cmd)

        if "ERROR" in result or "has been added" not in result:
            print(f"Error creating end entity:\n{result}")
            sys.exit(1)

        set_pwd_cmd = f'ra setclearpwd {username} {password}'
        run_cli(client, config, set_pwd_cmd)

        now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
        enrollment_url = f"{config['ra_base_url']}/ejbca/ra/cas.xhtml"

        print(f"{'='*50}")
        print(f"  End entity created successfully!")
        print(f"{'='*50}")
        print()
        print(f"  Organization:  {org_name}")
        print(f"  Username:      {username}")
        print(f"  Password:      {password}")
        print(f"  Country:       {country}")
        print(f"  DN:            {dn}")
        print()
        print(f"  Enrollment URL: {enrollment_url}")
        print()
        print(f"  Steps to enroll:")
        print(f"  1. Go to: {enrollment_url}")
        print(f"  2. Click on '{config['ca_name']}' in the list")
        print(f"  3. Login with username: {username}")
        print(f"  4. Enter password: {password}")
        print(f"  5. Click 'Enroll' to generate your certificate")
        print(f"  6. Download the P12 file")
        print(f"  7. Import into your application")
        print(f"{'='*50}")

        save_credentials(config, org_name, username, password, country, now)

    finally:
        client.close()


def save_credentials(config, org_name, username, password, country, timestamp):
    filepath = config.get("credentials_file", "issuers.txt")
    entry = (
        f"\n{'='*50}\n"
        f"Issuer: {org_name}\n"
        f"Created: {timestamp}\n"
        f"Status: Active\n"
        f"{'='*50}\n"
        f"Username: {username}\n"
        f"Password: {password}\n"
        f"Country: {country}\n"
        f"Enrollment URL: {config['ra_base_url']}/ejbca/ra/cas.xhtml\n"
        f"{'='*50}\n"
    )
    with open(filepath, "a") as f:
        f.write(entry)
    print(f"\nCredentials saved to: {filepath}")


def list_issuers():
    config = load_config()
    client = ssh_connect(config)
    try:
        cmd = (
            'docker exec ejbca-database mariadb -u ejbca -pejbca ejbca -e '
            '"SELECT username, status, tokenType FROM UserData '
            'WHERE username LIKE \'issuer-%\' ORDER BY username;" 2>&1'
        )
        result, err = run_command(client, cmd)

        lines = [l for l in result.strip().split("\n") if l and not l.startswith("-") and not l.startswith("username")]

        if not lines:
            print("No issuers found.")
            return

        print(f"\n{'='*60}")
        print(f"{'Issuer Registry':^60}")
        print(f"{'='*60}")
        print(f"{'Username':<38} {'Status':<10} {'Token':<8}")
        print(f"{'-'*60}")

        for line in lines:
            parts = line.split()
            if len(parts) >= 3:
                username = parts[0]
                status_code = parts[1]
                token = parts[2]
                status_map = {"10": "New", "20": "Generated", "30": "Revoked", "40": "Active", "50": "KeyRecovery"}
                status = status_map.get(status_code, status_code)
                token_map = {"0": "UserGen", "1": "P12", "2": "JKS", "3": "PEM"}
                token_name = token_map.get(token, token)
                print(f"{username:<38} {status:<10} {token_name:<8}")

        print(f"{'='*60}")
        print()

    finally:
        client.close()


def disable_issuer(username):
    config = load_config()
    client = ssh_connect(config)
    try:
        result = run_cli(client, config, f"ra disableendentity {username}")
        if "ERROR" in result:
            print(f"Error disabling {username}:\n{result}")
            sys.exit(1)
        print(f"Issuer '{username}' has been disabled.")

        update_status_in_file(config, username, "Disabled")

    finally:
        client.close()


def enable_issuer(username):
    config = load_config()
    client = ssh_connect(config)
    try:
        result = run_cli(client, config, f"ra enableendentity {username}")
        if "ERROR" in result:
            print(f"Error enabling {username}:\n{result}")
            sys.exit(1)
        print(f"Issuer '{username}' has been enabled.")

        update_status_in_file(config, username, "Active")

    finally:
        client.close()


def renew_issuer(username):
    config = load_config()
    client = ssh_connect(config)
    try:
        print(f"Renewing certificate for '{username}'...")
        print("To renew, the issuer should:")
        print(f"  1. Go to: {config['ra_base_url']}/ejbca/ra/cas.xhtml")
        print(f"  2. Login with username: {username}")
        print(f"  3. Click 'Renew' (if available) or 'Enroll'")
        print(f"  4. Download the new P12 file")
        print()
        print("If renewal is not available, re-create the end entity:")
        print(f"  python3 {os.path.basename(__file__)} disable {username}")
        print(f"  python3 {os.path.basename(__file__)} enable {username}")

    finally:
        client.close()


def update_status_in_file(config, username, status):
    filepath = config.get("credentials_file", "issuers.txt")
    if not os.path.exists(filepath):
        return

    with open(filepath, "r") as f:
        content = f.read()

    blocks = content.split("=" * 50)
    new_blocks = []

    for block in blocks:
        if f"Username: {username}" in block:
            lines = block.strip().split("\n")
            new_block_lines = []
            for line in lines:
                if line.startswith("Status:"):
                    new_block_lines.append(f"Status: {status}")
                else:
                    new_block_lines.append(line)
            block = "\n" + "\n".join(new_block_lines) + "\n"
        new_blocks.append(block)

    with open(filepath, "w") as f:
        f.write("=" * 50 + "=".join(new_blocks))


def interactive_mode():
    print("\nEJBCA Issuer CLI — Interactive Mode\n")
    print("Commands:")
    print("  1. Create new issuer")
    print("  2. List all issuers")
    print("  3. Disable an issuer")
    print("  4. Enable an issuer")
    print("  5. Renew certificate")
    print("  6. Exit")
    print()

    choice = input("Select command (1-6): ").strip()

    if choice == "1":
        org_name = input("Organization Name: ").strip()
        if not org_name:
            print("Error: Organization name is required.")
            sys.exit(1)
        password = input("Password (min 8 chars): ").strip()
        if len(password) < 8:
            print("Error: Password must be at least 8 characters.")
            sys.exit(1)
        country = input("Country [SD]: ").strip()
        if not country:
            country = None
        create_issuer(org_name, password, country)

    elif choice == "2":
        list_issuers()

    elif choice == "3":
        username = input("Username to disable: ").strip()
        if not username:
            print("Error: Username is required.")
            sys.exit(1)
        disable_issuer(username)

    elif choice == "4":
        username = input("Username to enable: ").strip()
        if not username:
            print("Error: Username is required.")
            sys.exit(1)
        enable_issuer(username)

    elif choice == "5":
        username = input("Username to renew: ").strip()
        if not username:
            print("Error: Username is required.")
            sys.exit(1)
        renew_issuer(username)

    elif choice == "6":
        print("Goodbye.")
        sys.exit(0)

    else:
        print("Invalid choice.")
        sys.exit(1)


def main():
    parser = argparse.ArgumentParser(description="EJBCA Issuer CLI — Self-service issuer management")
    subparsers = parser.add_subparsers(dest="command")

    create_parser = subparsers.add_parser("create", help="Create a new issuer")
    create_parser.add_argument("org_name", nargs="?", help="Organization name")
    create_parser.add_argument("password", nargs="?", help="Enrollment password (min 8 chars)")
    create_parser.add_argument("--country", default=None, help="Country code (default: SD)")

    subparsers.add_parser("list", help="List all issuers")

    disable_parser = subparsers.add_parser("disable", help="Disable an issuer")
    disable_parser.add_argument("username", help="Username to disable")

    enable_parser = subparsers.add_parser("enable", help="Enable an issuer")
    enable_parser.add_argument("username", help="Username to enable")

    renew_parser = subparsers.add_parser("renew", help="Renew certificate")
    renew_parser.add_argument("username", help="Username to renew")

    args = parser.parse_args()

    if args.command is None:
        interactive_mode()
    elif args.command == "create":
        if not args.org_name or not args.password:
            parser.error("create requires <org_name> and <password>")
        create_issuer(args.org_name, args.password, args.country)
    elif args.command == "list":
        list_issuers()
    elif args.command == "disable":
        disable_issuer(args.username)
    elif args.command == "enable":
        enable_issuer(args.username)
    elif args.command == "renew":
        renew_issuer(args.username)


if __name__ == "__main__":
    main()
